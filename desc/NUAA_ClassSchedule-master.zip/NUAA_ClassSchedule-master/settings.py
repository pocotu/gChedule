#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
settings  相关设置

@Author: MiaoTony
"""

DEBUG = False

VERSION = "V0.25.1.20230807"
